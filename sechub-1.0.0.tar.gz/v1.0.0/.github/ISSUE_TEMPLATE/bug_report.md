---
name: Bug report
about: Something is broken or behaving unexpectedly
labels: bug
---

**What happened**
A clear description of what went wrong.

**What you expected**
What you thought should happen.

**Reproduction**
1. Start with `…`
2. Click / call `…`
3. Observe `…`

**Environment**
- OS:
- Python version (`python3 --version`):
- Node version (`node --version`):
- How you ran it: scripts/start.sh · docker compose · other
- Branch / commit:

**Logs**
```
paste relevant lines from scripts/run/logs/backend.log or frontend.log
```
