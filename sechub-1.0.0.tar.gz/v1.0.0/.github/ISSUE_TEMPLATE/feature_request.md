---
name: Feature request
about: Suggest a new capability or signal
labels: enhancement
---

**The signal you'd like to surface**
e.g. "I want to see when a vendor's GitHub repo gets archived"

**Where it should live in the UI**
e.g. "as a new chip on the Vendor row in panel 8"

**Why it matters**
What operational decision does this signal change?

**Open questions**
What's unclear about the design?
