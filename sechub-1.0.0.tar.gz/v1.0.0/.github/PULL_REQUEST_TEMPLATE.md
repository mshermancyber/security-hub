## Summary
<!-- 1-3 bullets on what changed and why -->

## Checklist
- [ ] `./scripts/test.sh` passes locally
- [ ] Updated taxonomy entries if applicable (`backend/app/taxonomy/`)
- [ ] Added `.env.example` entry for any new env var
- [ ] External integrations degrade gracefully when unconfigured
- [ ] Documented user-facing changes in `USER_GUIDE.md` / `README.md`
